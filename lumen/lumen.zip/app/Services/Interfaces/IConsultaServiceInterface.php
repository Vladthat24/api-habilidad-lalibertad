<?php
namespace App\Services\Interfaces;
interface IConsultaServiceInterface{
	function postConsulta(string $an_o,string $cop);
}
