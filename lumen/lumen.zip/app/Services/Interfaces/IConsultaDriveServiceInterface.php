<?php
namespace App\Services\Interfaces;
interface IConsultaDriveServiceInterface{
    function postConsulta();
}
